using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calculator;
using System;

namespace UnitTestCalculator
{

    class ExampleException : Exception
    {

    }

    [TestClass]
    public class UnitTest1
    {
        [DataTestMethod]
        [DataRow(5, 9, 14)]
        [DataRow(1, 8, 9)]
        [DataRow(20, 30, 50)]
        [DataRow(100, 50, 150)]
        [DataRow(13, 13, 26)]
        [DataRow(0, 0, 0)]
        [DataRow(8, 7, 15)]
        
        public void TestMethodCalcul(string value1, string value2, int res)
        {
           
            var result = new ToolCalcul();
            int total = result.Calculate(value1, value2);

            Assert.AreEqual(total,res);
        }
    }
}
