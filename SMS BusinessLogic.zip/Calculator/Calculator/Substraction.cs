﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public class Substraction : IOperation
    {
        public int Calculate(int a, int b)
        {
            return a - b;
        }
    }
}
