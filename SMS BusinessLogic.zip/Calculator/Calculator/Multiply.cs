﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public class Multiply : IOperation
    {
        public int Calculate(int a, int b) => a * b;
    }
}
