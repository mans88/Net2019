﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public class ToolCalcul
    {
        public ToolCalcul(int nb1, int nb2, IOperation operation)
        {
            
        }
        /*public int Calculate(string nb1, string nb2,string format)
        {
                return Convert.ToInt32(nb1) + Convert.ToInt32(nb2);
                 }*/
    }
}
