﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Veuillez entrer la première valeur \n Valeur 1 : ");
            string value1 = Console.ReadLine();

            Console.WriteLine("Choisissez une opération a réaliser:");
            Console.WriteLine("+ - * /");
            string operation = Console.ReadLine();

            Console.WriteLine("Valeur 2 : ");
            string value2 = Console.ReadLine();

            var a = new ToolCalcul();
            int resultat = a.Calculate(value1,value2,operation);
            Console.WriteLine("le resulat est : " + resultat);
            Console.ReadKey();
        }
    }
}
