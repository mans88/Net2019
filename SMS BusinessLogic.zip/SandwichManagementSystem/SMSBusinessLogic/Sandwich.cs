﻿using System;
using System.Collections.Generic;

namespace SMSBusinessLogic
{
    public class Sandwich
    {
        public Language NameEnglish { get; set; }
        public Language NameFrench { get; set; }
        public Language NameDutch { get; set; }
        public Fournisseur Fournisseur { get; set; }
        public HashSet<Ingredient> Ingredients { get; }

        public bool AddIngredient(Ingredient ing)
        {
            return this.Ingredients.Add(ing);
        }

        public bool RemoveIngredient(Ingredient ing)
        {
            return this.Ingredients.Remove(ing);
        }

    }
}
