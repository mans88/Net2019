﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSBusinessLogic
{
    public enum Language
    {
        English,
        French,
        Dutch
    }
}
