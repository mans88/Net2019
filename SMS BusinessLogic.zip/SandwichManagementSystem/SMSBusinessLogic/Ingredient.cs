﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSBusinessLogic
{
    public class Ingredient
    {
        string NameFr;
        string nameNl;
        string nameEn;
        bool allergene;

        public string NameEnglish
        {
            get
            {

                return nameEn + (allergene ? "*" : "");

            }
            set
            {
                nameEn = value;
            }
        }

        public string NameFrench
        {
            get
            {

                return NameFr + (allergene ? "*" : "");

            }
            set
            {
                NameFr = value;
            }
        }
        public string NameNl
        {
            get
            {

                return nameNl + (allergene ? "*" : "");

            }
            set
            {
                nameNl = value;
            }
        }
        public bool Allergene
        {
            get
            {
                return allergene;
            }

            set
            {
                allergene = value;
            }

        }
    }

}

