﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSBusinessLogic
{
    public class GestionSandwich
    {
        static void Main(string[] args)
        {
            List<Ingredient> lIngredients = new List<Ingredient>
            {
                new Ingredient { NameNl = "salad", NameFrench = "salade", NameEnglish = "salad", Allergene = false },
                new Ingredient { NameNl = "salad", NameFrench = "tomate", NameEnglish = "tomaat", Allergene = false },
                new Ingredient { NameNl = "noten", NameFrench = "noix", NameEnglish = "nuts", Allergene = true }
            };

            Console.WriteLine("Bonjour pour avoir la liste tapez :");
            Console.WriteLine(" 1 pour le francais \n 2 pour le Neerlandais \n 3 pour l'anglais");
         //   int pos = Convert.ToInt32(Console.ReadKey());
        }
    }
}
