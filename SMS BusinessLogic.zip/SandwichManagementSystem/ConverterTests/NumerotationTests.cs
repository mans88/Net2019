﻿using Converter.Tools;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace NumerotationTests
{
    [TestClass]
    public class NumerotationTests
    {
        [DataTestMethod]
        [DataRow(1, "I")]
        [DataRow(8, "VIII")]
        [DataRow(17, "XVII")]
        [DataRow(46, "XLVI")]
        [DataRow(1030, "MXXX")]
        [DataRow(970, "CMLXX")]
        [DataRow(509, "DIX")]
        public void TestArabicToRoman(int valeur, string result)
        {
            var sut = Numerotation.ArabicToRoman(valeur);
            Assert.AreEqual(result, sut);
        }
    }
}
