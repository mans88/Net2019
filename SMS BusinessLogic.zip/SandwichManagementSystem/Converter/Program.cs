﻿using Converter.Tools;
using System;

namespace Converter
{
    public class Program
    {
        public static void Main(string[] args)
        {
            /*
            foreach (var item in args)
            {
                try
                {
                    var Celsius = Convert.ToInt32(item);
                    var Fahrenheit = Temperature.KelvinToFahrenheit(Celsius);
                    Console.WriteLine($"{Celsius}°C = {Fahrenheit}°F");
                }
                catch (Exception)
                {
                    Console.WriteLine($"'{item}' is not a number, try again.");
                }
            }
            */
            int[] Values = { 1, 8, 17, 46, 970, 1030 };
            int[] Values2 = { 1, 8 };
            foreach (int Value in Values2)
            {
                Console.WriteLine(Numerotation.ArabicToRoman(Value));
            }

            Console.ReadKey();
        }
    }
}
