﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Converter.Tools
{
    public enum TemperatureType
    {
        Celsius,
        Fahrenheit,
        Kelvin
    }
}
