﻿using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text;

namespace Converter.Tools
{
    public class Numerotation
    {
        public static string ArabicToRoman(int num)
        {
            if (num < 1 || num > 3999)
            {
                throw new ArgumentOutOfRangeException("Please use numbers between 1 and 3999");
            }

            var RomanSymbols = new (string Symbol, int Value)[]
            {
                ("M", 1000),
                ("CM", 900),
                ("D", 500),
                ("CD", 400),
                ("C", 100),
                ("XC", 90),
                ("L", 50),
                ("XL", 40),
                ("X", 10),
                ("IX", 9),
                ("V", 5),
                ("IV", 4),
                ("I", 1)
            };

            StringBuilder roman = new StringBuilder();
            foreach(var item in RomanSymbols)
            {
                while (num >= (int) item.Value)
                {
                    roman.Append(item.Symbol);
                    num -= (int) item.Value;
                }
            }
            return roman.ToString();
        }

        public static int RomanToArabic(string valeur)
        {
            return 0;
        }
    }
}
