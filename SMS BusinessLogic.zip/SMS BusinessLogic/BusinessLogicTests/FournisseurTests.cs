﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SMSBusinessLogic;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLogicTests
{
    [TestClass]
    class FournisseurTests
    {

        // Arrange
        [TestMethod]
        public void TestSandwishs()
        {
            //Arrange
            Fournisseur fournisseur1 = new Fournisseur("Manssour", "02/852 85 85", Language.French);
            Fournisseur fournisseur2 = new Fournisseur("Tarik", "01/542 85 77", Language.English);
            Fournisseur fournisseur3 = new Fournisseur("Gauthier", "03/725 68 12", Language.Dutch);

            //Assert

        }
    }
}
