﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLogic
{
    public enum Pain
    {       Cereal,
            Gris,
            Blanc

    }
}
