﻿using BusinessLogic;
using System;
using System.Collections.Generic;
using System.Text;

namespace SMSBusinessLogic
{
    public class Ingredient
    {
        public bool Allergen { get; set; }
        public Translated Name { get; set; }

        public Ingredient() { }

        public Ingredient(Translated translated, bool allergen = false)
        {
            Name = translated;
            this.Allergen = allergen;
        }

        public string ToString(Language lang)
        {
            StringBuilder result = new StringBuilder();
            result.Append(Name.ToString(lang));

            if (this.Allergen)
                result.Append("*");
            return result.ToString();
        }
    }
}
