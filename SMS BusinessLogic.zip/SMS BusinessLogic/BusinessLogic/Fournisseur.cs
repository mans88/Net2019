﻿using BusinessLogic;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace SMSBusinessLogic
{
    public class Fournisseur
    {
        public string Name { get; set; }
        public string ContactName { get; set; }
        //public string Email { get; set; }
        public Language LanguageChoice { get; set; }
        public List<Sandwich> Sandwichs { get; }
        public List<Pain> Pains { get; }

        public Fournisseur(string name,string ContactName,Language lang)
        {
            Name = name;
            LanguageChoice = lang;
            this.ContactName = ContactName;
            Sandwichs = new List<Sandwich>();
            Pains = new List<Pain>();
        }

        public override string ToString()
        {
            string res;
            res = (Name + "\n");
            res += string.Join("\n", Sandwichs.Select(s => s.ToString(LanguageChoice)));
            return res;
        }
    }
}
