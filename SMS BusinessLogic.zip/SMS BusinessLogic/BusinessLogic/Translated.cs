﻿using SMSBusinessLogic;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLogic
{
    public class Translated
    {
        public Translated(string en, string fr, string nl)
        {
            English = en;
            French = fr;
            Dutch = nl;
        }

        public string English { get; set; }
        public string French { get; set; }
        public string Dutch { get; set; }
        public string ToString(Language language)
        {
            switch (language)
            {
                case Language.English:
                    return English;
                case Language.French:
                    return French;
                case Language.Dutch:
                    return Dutch;
                default:
                    throw new Exception("Language not know");
            }
        }
    }
}
