﻿using BusinessLogic;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SMSBusinessLogic
{
    public class Sandwich
    {
        public Translated Name { get; set; }
        public Fournisseur Fournisseur { get; set; }
        public List<Ingredient> Ingredients { get; }
        

        public Sandwich()
        {
            this.Ingredients = new List<Ingredient>();
        }
        public Sandwich(Translated translated, Fournisseur fournisseur) : this()
        {
            this.Name = translated;
            this.Fournisseur = fournisseur;
        }

        public bool HasAllergen()
        {
            foreach (Ingredient ing in this.Ingredients)
            {
                if (ing.Allergen)
                    return true;
            }
            return false;
        }

        public string ToString(Language lang)
        {
            StringBuilder Result = new StringBuilder();
            Result.Append(Name.ToString(lang));

            Result.Append(" - ");
            Result.Append(string.Join(", ", Ingredients.Select(x => x.ToString(lang))));
            return Result.ToString();
        }
    }
}
