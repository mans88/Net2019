﻿using MonProjet02OOPBasic.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonProjet02OOPBasic
{
    class Client
    {
        static void Main(string[] args)
        {

            Working_With_Inheritence();
        }

        private static void Working_With_Inheritence()
        {
            Compte compte1 = new Compte { Numero = "C1000", Proprietaire = "Manssour HAMDI", Solde = 1000};
            Compte compte2 = new Compte { Numero = "C2000", Proprietaire = "Patrick PEYCKER", Solde = 2000 };
            Compte compte3 = new CompteEpargne { Numero = "C3000", Proprietaire = "Mans HMD", Solde = 3000, Taux = 10 };

            List<Compte> data = new List<CompteEpargne> { compte1, compte2,compte3 };

            foreach (var item in data)
            {
                Console.WriteLine(item);
            }
        }
    }
}
