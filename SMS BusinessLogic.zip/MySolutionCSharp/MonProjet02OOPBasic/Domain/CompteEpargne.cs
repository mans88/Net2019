﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonProjet02OOPBasic.Domain
{
    class CompteEpargne : Compte
    {
        public decimal Taux { get; set; }

        public CompteEpargne(string num, string proprio, decimal solde, decimal taux) : base(num, proprio, solde)
        {
            this.Taux = taux;
        }
        public override string ToString()
        {
            return base.ToString() + " pour un taux " + Taux;
        }
    }
}
