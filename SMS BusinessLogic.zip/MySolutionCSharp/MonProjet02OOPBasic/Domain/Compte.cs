﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonProjet02OOPBasic.Domain
{
    class Compte
    {
        private string num;
        private string proprio;
        private decimal solde;

        public virtual decimal GetSolde() => Solde;
        public Compte(string num, string proprio, decimal solde)
        {
            this.num = num;
            this.proprio = proprio;
            this.Solde = solde;
        }

        public string Numero { get ; set; }
        public string Proprietaire { get; set; }
        public decimal Solde { get; set; }

        public override string ToString() => $"Compte : {Numero} de {Proprietaire} ayant le solde de {solde}";
    }
}
