﻿using System;

namespace MonProjetHello
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < int.Parse(args[0]); i++)
            {
                GreatMethode(i);
            }
        }

        private static void GreatMethode(int i)
        {
            Console.WriteLine($"Iteration {i + 1} Hello world C# !!!");
        }
    }
}
